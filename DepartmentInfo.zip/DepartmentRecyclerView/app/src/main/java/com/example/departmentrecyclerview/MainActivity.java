package com.example.departmentrecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recycle;
    ArrayList<Department> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list=new ArrayList<Department>();
        list.add(new Department("CSE","Top in placements"));
        list.add(new Department("MECH","Showoff Department"));
        list.add(new Department("IT","Trying to be a competitor for CSE but fails"));
        list.add(new Department("ECE","Contains Both EEE and CSE"));
        recycle=(RecyclerView)findViewById(R.id.recycler);
        recycle.setLayoutManager(new LinearLayoutManager(this));
        recycle.setAdapter(new DepartmentAdapter(list, new DepartmentAdapter.OnListItemClick() {
            @Override
            public void onClick(int position) {
                    Intent intnt=new Intent(MainActivity.this,DisplayActivity.class);
                    intnt.putExtra("department",new Department(list.get(position)));
                    startActivity(intnt);
            }
        }));
        recycle.setHasFixedSize(true);
    }
}
